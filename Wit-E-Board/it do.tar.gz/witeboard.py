# server_version.py - retrieve and display database server version

import MySQLdb
import serial

ser = serial.Serial('/dev/ttyACM0')
print ser.name

conn = MySQLdb.connect (host = "localhost",
user = "witeboard",
passwd = "password",
db = "witeboard")
cursor = conn.cursor ()
cursor.execute ("SELECT VERSION()")
row = cursor.fetchone ()

while (1 == 1):
	input = ser.readline()
	print input

	data = ""
	time = 0
	sensor = 1
	inputlist = input.split(";")
	data += "INSERT INTO coordinates (id1, time1, id2, time2) VALUE("

	for item in inputlist:
		time = not time
		data += item+", "

	data = data[:-3]
	data+=");"
	print data


	cursor.execute(data)
	conn.commit()


cursor.close ()
conn.close ()
