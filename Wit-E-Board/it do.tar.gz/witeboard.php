<?php
	$passwd="password";
	$con=mysqli_connect("localhost", "witeboard", $passwd, "witeboard");

	if (mysqli_connect_errno()){
		echo "Failed to connect to MySQL: " . mysqli_connect_error();
	}
	else{
		$query="SELECT * FROM witeboard.coordinates;";
		$result=mysql_query($query);
		if (!$result) {
			$message  = 'Invalid query: ' . mysql_error() . "\n";
			$message .= 'Whole query: ' . $query;
			die($message);
		}
		
		$coordarray = array();

		while($row = mysql_fetch_assoc($result)){
			array_push($coordarray, $row['time1']);
			array_push($coordarray, $row['time2']);
		}
		

		echo json_encode($coordarray);
	}
?>
